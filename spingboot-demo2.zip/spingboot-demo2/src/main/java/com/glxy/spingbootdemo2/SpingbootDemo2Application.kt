package com.glxy.spingbootdemo2

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
object SpingbootDemo2Application {

    @JvmStatic
    fun main(args: Array<String>) {
        SpringApplication.run(SpingbootDemo2Application::class.java, *args)
    }

}
