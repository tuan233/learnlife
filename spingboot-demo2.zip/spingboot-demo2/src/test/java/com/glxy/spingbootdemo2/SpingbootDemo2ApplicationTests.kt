package com.glxy.spingbootdemo2

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
internal class SpingbootDemo2ApplicationTests {

    @Test
    fun contextLoads() {
    }

}
